import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reach',
  templateUrl: './reach.component.html',
  styleUrls: ['./reach.component.scss']
})
export class ReachComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
