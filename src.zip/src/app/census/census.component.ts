import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-census',
  templateUrl: './census.component.html',
  styleUrls: ['./census.component.scss']
})
export class CensusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
