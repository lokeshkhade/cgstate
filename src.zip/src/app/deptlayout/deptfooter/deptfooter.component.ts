import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deptfooter',
  templateUrl: './deptfooter.component.html',
  styleUrls: ['./deptfooter.component.scss']
})
export class DeptfooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
