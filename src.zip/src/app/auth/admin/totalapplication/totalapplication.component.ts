import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-totalapplication',
  templateUrl: './totalapplication.component.html',
  styleUrls: ['./totalapplication.component.scss']
})
export class TotalapplicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
