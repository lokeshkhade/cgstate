import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-impinfo',
  templateUrl: './impinfo.component.html',
  styleUrls: ['./impinfo.component.scss']
})
export class ImpinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
