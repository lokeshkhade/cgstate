import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-districts',
  templateUrl: './districts.component.html',
  styleUrls: ['./districts.component.scss']
})
export class DistrictsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
