export const environment = {
  production: true,
  rootUrl: ''
};
